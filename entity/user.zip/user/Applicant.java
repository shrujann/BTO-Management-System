package entity.user;

/*
 * Represents an applicant in the BTO Management System.
 * Applicant Responsibilities: 
 *  1. View available projects.
 *  2. Apply for projects (with certain restrictions based on marital status and age).
 *  3. View their application status.
 *  4. Request withdrawal of their application.
 *  5. Submit, view, edit, and delete enquiries.
 */
public class Applicant extends User {
  /**
   * Constructor for the Applicant class.
   * @param userID        The applicant's NRIC.
   * @param password      The applicant's password.
   * @param age           The applicant's age.
   * @param maritalStatus The applicant's marital status.
   */
  public Applicant(String name, String userID, int age, String maritalStatus, String password) {
    super(name, userID, age, maritalStatus, password);
  }

  /**
   * toString method for Applicant class
   * @return string representation of Applicant
   */
  @Override
  public String toString() {
    return "Applicant{" +
           "userID: '" + getUserID() + '\'' +
           ", age: " + getAge() +
           ", maritalStatus: '" + getMaritalStatus() + '\'' +
           '}';
  }
}