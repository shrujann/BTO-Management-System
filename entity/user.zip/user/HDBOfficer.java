package entity.user;

import entity.project.BTOProject;

/*
 * Represents an HDB Officer in the BTO Management System.
 * Extends the Applicant class and includes specific attributes and methods for HDB officers.
 */
public class HDBOfficer extends Applicant {
  private boolean isRegisteredForProject;
  private String registrationStatus; // Pending, Approved, Rejected
  private BTOProject projectAssigned;

  /**
   * Constructor for the HDBOfficer class.
   * @param userID        The officer's NRIC.
   * @param password      The officer's password.
   * @param age           The officer's age.
   * @param maritalStatus The officer's marital status.
   */
  public HDBOfficer(String name, String userID, int age, String maritalStatus, String password) {
    super(name, userID, age, maritalStatus, password);
    this.isRegisteredForProject = false;
    this.registrationStatus = "Pending"; // Default status
    this.projectAssigned = null;
    }

    // Getters and setters for attributes
    public String getRegistrationStatus() {return registrationStatus;}
    public void setRegistrationStatus(String registrationStatus) {this.registrationStatus = registrationStatus;}
    
    public boolean isRegisteredForProject() {return isRegisteredForProject;}
    public void setRegisteredForProject(boolean registeredForProject) {isRegisteredForProject = registeredForProject;}
    
    public BTOProject getProjectAssigned() {return projectAssigned;}
    public void setProjectAssigned(BTOProject projectAssigned) {this.projectAssigned = projectAssigned;}
}